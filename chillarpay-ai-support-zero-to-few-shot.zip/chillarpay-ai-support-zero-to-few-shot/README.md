# ChillarPay AI Support: From Zero-Shot to Few-Shot Prompting

**A FinTech case study on when a simple prompt is enough and when AI needs examples.**

**Author:** [Your Name] · **Programme:** BBA (FinTech / AI) · **Institution:** [Your Institution] · **Tool:** ChatGPT (GPT-6) · **Date:** November 2026

## The case

**ChillarPay** is a fictional UPI payments app in Jaipur with 8 lakh users. It receives approximately 2,000 support messages a day in English and Hinglish. Its six-person support team struggles to keep up, and urgent fraud cases can get lost among routine questions.

As a Business Analyst, I examined whether AI can classify support messages, assign priority, and draft replies—and whether zero-shot or few-shot prompting is more suitable.

## Project objectives

- Classify messages into Failed Payment, Refund, Fraud Alert, or Account & KYC.
- Assign High, Medium, or Low priority using the stated ChillarPay rules.
- Draft short, polite replies in English or Hinglish.
- Compare zero-shot and few-shot prompting on the same synthetic dataset.

## Dataset

The project uses **12 synthetic customer messages**: 8 in English and 4 in Hinglish. It includes all four categories and three deliberately tricky cases: a cross-category message (M11), a very short/unclear message (M09), and an angry customer (M10). No real customer identifiers or private payment data are used.

## Repository structure

| File | Contents |
|---|---|
| `01_case_study.md` | Business context, support rules, workflow, and safeguards |
| `02_dataset.md` | Synthetic messages and suggested pre-test answer key |
| `03_zero_shot_summary.md` | Zero-shot summaries |
| `04_zero_shot_triage.md` | Zero-shot category, priority, and reply output |
| `05_few_shot_triage.md` | Few-shot output using three solved examples |
| `06_scorecard.md` | Evaluation, reflection, and recommendation |

## Method

| Stage | Prompt approach | Task |
|---|---|---|
| 1 | Zero-shot | Summarise each customer message in one line |
| 2 | Zero-shot | Predict category, priority, and reply |
| 3 | Few-shot (3 examples) | Repeat the same triage task with examples |

The zero-shot and few-shot triage stages use the same 12 messages. The few-shot stage adds three solved examples to demonstrate ChillarPay's intended decisions and reply style.

## Results

| Metric | Zero-shot | Few-shot |
|---|---:|---:|
| Correct category (/12) | 11 | 12 |
| Correct priority (/12) | 11 | 12 |
| Reply follows ChillarPay tone (/12) | 9 | 12 |
| Table format followed (/12) | 12 | 12 |

These are **illustrative scores** based on the model-generated outputs and suggested answer key included in this learning project. M04 and M09 use documented provisional priority assumptions because the case rules do not explicitly resolve those situations. See `06_scorecard.md` for the evaluation method and limitations.

## Key learnings

1. **Zero-shot works for familiar tasks:** A clear instruction was sufficient for short message summaries.
2. **Few-shot demonstrates company-specific rules:** Three examples helped align category selection, priority, and reply style.
3. **Hinglish and tricky cases need attention:** Examples improved language matching and helped surface the fraud risk in M11.
4. **Ambiguity remains a human-review issue:** M09 does not state whether money was deducted, so the system should ask a clarifying question rather than assume facts.

## Recommendation to ChillarPay

Use a few-shot prompt as the starting point for daily triage because it makes the company's decision rules and tone more concrete. Immediately route suspected fraud and blocked-account cases to human agents, and require human review for ambiguous cases and all sensitive financial actions.

## Skills demonstrated

Prompt engineering · Zero-shot and few-shot prompting · Synthetic data creation · AI output evaluation · Customer-support operations · FinTech domain knowledge · Business analysis

## Responsible AI and limitations

- ChillarPay and all customer messages are fictional.
- This small test dataset does not prove production readiness or guarantee accuracy.
- AI outputs should remain drafts; a human must review high-risk and ambiguous cases.
- Production use would require privacy controls, monitoring, representative testing, and a defined escalation process.

---

*Created for academic learning. ChillarPay and all data in this repository are fictional.*
