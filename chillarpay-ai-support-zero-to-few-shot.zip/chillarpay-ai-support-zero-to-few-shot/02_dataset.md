# ChillarPay Synthetic Support Dataset

## Dataset purpose

This dataset is designed to test whether prompting techniques can classify, prioritise, and draft replies to realistic UPI support messages. All messages are fictional.

- **Total messages:** 12
- **Language mix:** 8 English and 4 Hinglish
- **Channels:** App chat, Email, Twitter
- **Tricky cases:** cross-category message (M11), very short/unclear message (M09), angry customer (M10)

## Customer messages

| ID | Customer message | Channel |
|---|---|---|
| M01 | My payment failed, but ₹500 was deducted from my bank account. Please check what happened. | App chat |
| M02 | I requested a refund five days ago, but I still haven't received my money. | Email |
| M03 | I noticed a transaction of ₹2,000 that I never made. Someone may have accessed my account. | App chat |
| M04 | I am unable to complete my KYC verification. The app keeps showing an error. | App chat |
| M05 | Paise kat gaye lekin shopkeeper ko payment nahi mila. Ab main kya karu? | App chat |
| M06 | Mujhe mera refund abhi tak nahi mila. Please jaldi help karo. | Twitter |
| M07 | My account has been blocked, and I cannot send or receive any payments. | Email |
| M08 | Someone made a payment from my account without asking me, and now my balance is missing. | App chat |
| M09 | Payment nahi hua. | App chat |
| M10 | Your app is completely useless! My money is stuck, nobody is responding, and I am tired of waiting. | Twitter |
| M11 | Mujhe KYC expire hone ka message aaya aur uske baad mere account se ₹1,000 gayab ho gaye. | Email |
| M12 | How can I change my registered email address in my ChillarPay account? | App chat |

## Analyst answer key — review before submission

> **Academic integrity note:** The assignment asks the student to write the answer key independently before reviewing AI outputs. The table below is a suggested working key prepared with AI assistance. Verify each row against the case rules and rewrite/confirm it independently before submitting if your instructor requires a no-AI answer key.

| ID | Suggested correct category | Suggested priority | Rationale / review note |
|---|---|---|---|
| M01 | Failed Payment | Medium | Payment failed but money was deducted/stuck. |
| M02 | Refund | Medium | Refund is pending. |
| M03 | Fraud Alert | High | Customer reports a transaction they did not make. |
| M04 | Account & KYC | Low* | KYC help request; account is not stated to be blocked. |
| M05 | Failed Payment | Medium | Money was deducted but the merchant did not receive it. |
| M06 | Refund | Medium | Refund has not arrived. |
| M07 | Account & KYC | High | Account is blocked. |
| M08 | Fraud Alert | High | Payment was made without the customer's consent. |
| M09 | Failed Payment | Medium* | Very unclear; provisional classification only. Ask whether money was deducted. |
| M10 | Failed Payment | Medium | Customer says money is stuck; angry tone does not change the priority rule. |
| M11 | Fraud Alert | High | Possible scam/KYC-message context plus money missing; could also involve Account & KYC. Escalate for human review. |
| M12 | Account & KYC | Low | Information request about changing a profile detail. |

\* **Assumptions requiring human review:** The policy does not explicitly assign priority to a KYC error or a message that only says “Payment nahi hua.” Low for M04 and Medium for M09 are provisional choices for this exercise. M11 is intentionally cross-category; Fraud Alert is selected as the primary category because the key risk is unexplained money loss.

## Dataset quality checks

- [x] 12 fictional messages
- [x] 8 English messages
- [x] 4 Hinglish messages
- [x] All four support categories represented
- [x] One cross-category case (M11)
- [x] One very short/unclear case (M09)
- [x] One angry-customer case (M10)
- [x] No real names, phone numbers, account numbers, or UPI IDs
