# Step 7 — Prompt Comparison Scorecard and Reflection

## Scorecard

Scores are based on the row-by-row evaluation tables in Steps 5 and 6. A reply-tone pass requires a polite, short reply in the customer's language, with no refund-date promise and a first name used when one is supplied.

| Metric | Zero-shot | Few-shot |
|---|---:|---:|
| Correct category (out of 12) | 11/12 | 12/12 |
| Correct priority (out of 12) | 11/12 | 12/12 |
| Reply follows ChillarPay tone (out of 12) | 9/12 | 12/12 |
| Table format followed (out of 12) | 12/12 | 12/12 |

> Scores are illustrative for the model-generated outputs in this repository. The answer key contains two documented assumptions (M04 and M09); confirm those with your instructor or business owner before treating them as formal policy.

## Reflection (approximately 150 words)

Zero-shot prompting was good enough for summarising because the task was familiar and required only a short description of each message. It also handled most routine classification cases correctly. Few-shot prompting improved the company-specific task by showing how ChillarPay applies its rules and how replies should sound. In this test, it corrected the cross-category M11 decision from Account & KYC / Medium to Fraud Alert / High, and it produced Hinglish replies for M05, M06 and M11. The short M09 message still needs clarification because it does not say whether money was deducted; a human should verify the provisional Medium priority. I recommend a few-shot prompt for daily triage because consistency in priority and language matters, especially when fraud reports are mixed with routine questions. However, AI should only draft and route cases. Human agents must review High-priority cases, ambiguous messages, and all actions involving customer funds.

## Business Analyst recommendation

Use a controlled few-shot prompt for routine classification and reply drafting because the examples demonstrate ChillarPay's category boundaries, escalation logic, and language expectations. Route suspected fraud and blocked-account cases to human agents immediately. Keep human review for ambiguous messages and never allow an unverified AI draft to promise a refund date or claim that money has been recovered.

## Limitations and next steps

- The dataset contains only 12 synthetic messages and cannot establish production-level accuracy.
- The case policy does not fully specify priority for every KYC error or unclear payment message.
- Test on a larger, representative, privacy-safe dataset before deployment.
- Measure category accuracy, priority accuracy, language compliance, escalation recall for fraud, and human correction rate.
- Add a confidence/uncertainty flag and a manual-review queue for ambiguous cases.
