# Step 5 — Zero-Shot Classification, Priority, and Reply Drafts

## Prompt used

```text
You are a customer-support assistant for ChillarPay, a UPI payments app.
For each customer message below, give:
1. Category: one of Failed Payment, Refund, Fraud Alert, Account & KYC
2. Priority: High, Medium or Low, using this rule:
   High = money lost without the customer's consent, or account blocked
   Medium = money stuck or delayed, refund pending
   Low = information request or profile update
3. Reply: a reply in ChillarPay's tone: polite and short; use the customer's first name if given; never promise a refund date; reply in Hinglish if the customer writes in Hinglish.
Output a table: ID | Category | Priority | Reply (maximum 25 words)
Messages:
[the same 12 messages from 02_dataset.md]
```

## Model-generated output

| ID | Category | Priority | Reply (maximum 25 words) |
|---|---|---|---|
| M01 | Failed Payment | Medium | Sorry for the inconvenience. Please share the transaction details through the app so our team can check the failed payment. |
| M02 | Refund | Medium | We understand your concern. Please share your refund reference so our team can check its current status. |
| M03 | Fraud Alert | High | We are sorry. Please secure your account and report this unauthorised transaction to our support team immediately. |
| M04 | Account & KYC | Low | Please check that your KYC details are correct and try verification again. Contact support if the error continues. |
| M05 | Failed Payment | Medium | Sorry for the trouble. Please share the transaction details so we can check the payment status. |
| M06 | Refund | Medium | We understand your concern. Please share your refund reference so our team can check the status. |
| M07 | Account & KYC | High | We are sorry for the inconvenience. Please contact support for an urgent review of your blocked account. |
| M08 | Fraud Alert | High | Please secure your account immediately and report the unauthorised payment to our support team. |
| M09 | Failed Payment | Medium | Please share whether money was deducted and provide the transaction details so we can help. |
| M10 | Failed Payment | Medium | We are sorry for the inconvenience. Please share the transaction details so our team can investigate the stuck money. |
| M11 | Account & KYC | Medium | Please do not share OTPs. Contact support so we can review the KYC message and missing balance. |
| M12 | Account & KYC | Low | You can change your registered email address in the Profile section of the ChillarPay app. |

## Evaluation against the suggested answer key

| ID | Category | Priority | Reply tone | Notes |
|---|---|---|---|---|
| M01 | ✔ | ✔ | ✔ | — |
| M02 | ✔ | ✔ | ✔ | No refund date promised. |
| M03 | ✔ | ✔ | ✔ | Urgent unauthorised transaction. |
| M04 | ✔ | ✔* | ✔ | Low is the provisional KYC-help assumption. |
| M05 | ✔ | ✔ | ✘ | Hinglish message received an English reply. |
| M06 | ✔ | ✔ | ✘ | Hinglish message received an English reply. |
| M07 | ✔ | ✔ | ✔ | Blocked account marked High. |
| M08 | ✔ | ✔ | ✔ | Unauthorised payment marked High. |
| M09 | ✔ | ✔* | ✔ | Provisional Medium; asks a useful clarification. |
| M10 | ✔ | ✔ | ✔ | Angry tone handled politely; money-stuck issue is Medium. |
| M11 | ✘ | ✘ | ✘ | Cross-category risk was labelled Account & KYC / Medium; Hinglish reply rule missed. |
| M12 | ✔ | ✔ | ✔ | Profile information request marked Low. |

*Provisional scoring follows the assumptions documented in `02_dataset.md`. This is a model-generated demonstration output; retain the actual unedited output from your own prompt run if your instructor requires a verbatim run record.
