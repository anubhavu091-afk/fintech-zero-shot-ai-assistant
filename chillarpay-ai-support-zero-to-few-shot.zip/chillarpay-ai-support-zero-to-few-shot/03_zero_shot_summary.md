# Step 4 — Zero-Shot Message Summaries

## Prompt used

```text
Summarise each ChillarPay customer message below in one short line (maximum 12 words).
Output a table: ID | Summary
Messages:
[the 12 messages from 02_dataset.md]
```

## Model output

| ID | Summary |
|---|---|
| M01 | Payment failed despite ₹500 being deducted from the customer's bank. |
| M02 | Customer has not received a refund requested five days ago. |
| M03 | Customer reports an unauthorised ₹2,000 transaction. |
| M04 | KYC verification fails because the app displays an error. |
| M05 | Money was deducted, but the shopkeeper did not receive payment. |
| M06 | Customer is waiting for a pending refund. |
| M07 | Customer's account is blocked, preventing payments. |
| M08 | An unauthorised payment was made and the customer's balance is missing. |
| M09 | Customer says the payment did not happen. |
| M10 | Angry customer says money is stuck and support has not responded. |
| M11 | Customer received a KYC-expiry message before ₹1,000 went missing. |
| M12 | Customer wants to change the registered email address. |

## Observation

Zero-shot prompting is suitable for this summarisation task because the instruction is simple and the expected output is familiar. The summaries preserve the main issue without needing company-specific examples.

The summaries do not decide the final category, priority, or next action. Those tasks require closer application of ChillarPay's internal rules, particularly for M09 and M11.
