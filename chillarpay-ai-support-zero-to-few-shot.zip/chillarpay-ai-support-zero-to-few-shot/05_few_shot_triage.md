# Step 6 — Few-Shot Classification, Priority, and Reply Drafts

## Prompt used

The Step 5 prompt was retained and three solved examples were added. The customer messages were unchanged.

```text
You are a customer-support assistant for ChillarPay, a UPI payments app.
For each customer message below, give:
1. Category: one of Failed Payment, Refund, Fraud Alert, Account & KYC
2. Priority: High, Medium or Low, using this rule:
   High = money lost without the customer's consent, or account blocked
   Medium = money stuck or delayed, refund pending
   Low = information request or profile update
3. Reply: a reply in ChillarPay's tone: polite and short; use the customer's first name if given; never promise a refund date; reply in Hinglish if the customer writes in Hinglish.
Output a table: ID | Category | Priority | Reply (maximum 25 words)
Learn from these examples and follow the same style exactly:
Message: Bhai mere account se ₹3,000 kat gaye, maine koi payment nahi kiya!
Output: Fraud Alert | High | Humein afsos hai. Turant app mein UPI block karein; hamari fraud team ise priority par check kar rahi hai.
Message: Paid ₹450 to a shop, money debited but the shop didn't get it. I want a refund.
Output: Failed Payment | Medium | Sorry for the trouble. Failed payments usually reverse automatically; please share the transaction ID so we can track it.
Message: How do I change my registered email?
Output: Account & KYC | Low | You can update your email under Profile > Settings in the ChillarPay app.
Messages:
[the SAME 12 messages from 02_dataset.md]
```

## Model-generated output

| ID | Category | Priority | Reply (maximum 25 words) |
|---|---|---|---|
| M01 | Failed Payment | Medium | Sorry for the trouble. Please share the transaction details so we can check the failed payment. |
| M02 | Refund | Medium | We understand your concern. Please share your refund reference so our team can check the status. |
| M03 | Fraud Alert | High | We are sorry. Please secure your account and report this unauthorised transaction immediately. |
| M04 | Account & KYC | Low | Please check your KYC details and try again. If the error continues, contact our support team. |
| M05 | Failed Payment | Medium | Humein afsos hai. Kripya transaction details share karein, taaki hum payment status check kar sakein. |
| M06 | Refund | Medium | Humein khed hai. Kripya apna refund reference share karein, hum status check karne mein madad karenge. |
| M07 | Account & KYC | High | We are sorry for the inconvenience. Please contact support for an urgent review of your blocked account. |
| M08 | Fraud Alert | High | Please secure your account immediately and report this unauthorised payment to our support team. |
| M09 | Failed Payment | Medium | Payment deduct hua tha kya? Kripya details share karein, taaki hum issue samajh kar madad kar sakein. |
| M10 | Failed Payment | Medium | We are sorry for the trouble. Please share the transaction details so our team can check the stuck money. |
| M11 | Fraud Alert | High | Humein afsos hai. Apna account secure karein aur is transaction ko turant fraud team ko report karein. |
| M12 | Account & KYC | Low | You can update your registered email under Profile > Settings in the ChillarPay app. |

## Evaluation against the suggested answer key

| ID | Category | Priority | Reply tone | Notes |
|---|---|---|---|---|
| M01 | ✔ | ✔ | ✔ | — |
| M02 | ✔ | ✔ | ✔ | No refund date promised. |
| M03 | ✔ | ✔ | ✔ | High-priority unauthorised transaction. |
| M04 | ✔ | ✔* | ✔ | Low is the provisional KYC-help assumption. |
| M05 | ✔ | ✔ | ✔ | Hinglish reply. |
| M06 | ✔ | ✔ | ✔ | Hinglish reply. |
| M07 | ✔ | ✔ | ✔ | Blocked account marked High. |
| M08 | ✔ | ✔ | ✔ | Unauthorised payment marked High. |
| M09 | ✔ | ✔* | ✔ | Provisional Medium; reply asks whether money was deducted. |
| M10 | ✔ | ✔ | ✔ | Polite reply despite customer's anger. |
| M11 | ✔ | ✔ | ✔ | Fraud risk prioritised; Hinglish reply. |
| M12 | ✔ | ✔ | ✔ | Profile update guidance. |

*Provisional scoring follows the assumptions documented in `02_dataset.md`. This is a model-generated demonstration output; retain the actual unedited output from your own prompt run if your instructor requires a verbatim run record.
