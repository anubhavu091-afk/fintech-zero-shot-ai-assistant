# ChillarPay: Business Case and Support Rules

## Project overview

**ChillarPay** is a fictional UPI payments app based in Jaipur, used primarily by college students and small shopkeepers. The app has approximately **8 lakh users** and receives around **2,000 customer-support messages per day** in English and Hinglish.

Its six-person support team struggles to keep up with incoming messages. Urgent fraud reports can get buried among routine questions, creating operational risk and a poor customer experience.

## Business question

The Head of Customer Experience asks:

> Can AI classify incoming messages, assign priority, and draft replies? When is a simple prompt sufficient, and when does the AI need examples?

## Support taxonomy and decision rules

| Area | ChillarPay rule |
|---|---|
| Supported categories | Failed Payment, Refund, Fraud Alert, Account & KYC |
| **High priority** | Money lost without the customer's consent, or account blocked |
| **Medium priority** | Money stuck or delayed, or refund pending |
| **Low priority** | Information request or profile update |
| Reply tone | Polite and short; use the customer's first name if provided; never promise a refund date; reply in Hinglish when the customer writes in Hinglish |

### Operational interpretation

The case rules do not explicitly define priority for every possible KYC-verification problem or unclear message. For this exercise, an unblocked KYC-help request is provisionally treated as **Low**, while a very short message is assigned a provisional category and priority and should be clarified by a human agent. These are working assumptions, not additional official ChillarPay policy.

## Proposed AI-assisted workflow

1. Receive a customer message from App chat, Email, or Twitter.
2. Classify it into one of the four approved categories.
3. Assign High, Medium, or Low priority using the rules above.
4. Draft a short reply in the customer's language.
5. Route High-priority cases—especially suspected unauthorized transactions and blocked accounts—to a human support agent immediately.
6. Have a human review replies and ambiguous cases before sending.

## Scope and safeguards

- All messages in this project are synthetic and contain no real customer identifiers.
- AI output is a draft, not an autonomous decision or a substitute for fraud investigation.
- The team should monitor classification errors, priority errors, language consistency, and reply quality.
- Do not promise a refund date or claim that an investigation or reversal has occurred unless verified by an authorised system.
